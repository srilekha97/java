package com.capgemini.MobilePurchaseSystem.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import com.capgemini.MobilePurchaseSystem.dao.MobilePurchaseSystemDaoImpl;
import com.capgemini.MobilePurchaseSystem.dto.CustomerDto;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilePurchaseSystemException;


public class MobilePurchaseSystemServiceImpl implements IMobilePurchaseSystemService{
	MobilePurchaseSystemDaoImpl mpDao;
	
	public MobilePurchaseSystemServiceImpl(){
		 mpDao = new MobilePurchaseSystemDaoImpl();
	}
	
	@Override
	public CustomerDto mobilePurchaseSystem(CustomerDto customerMps)
			throws MobilePurchaseSystemException {
		return mpDao.mobilePurchaseSystem(customerMps);
	}
	public int getPID() throws MobilePurchaseSystemException, SQLException{
		return mpDao.getPID();
	}
	public ArrayList<Long> getMobileId() throws SQLException, MobilePurchaseSystemException{
		return mpDao.getMobileId();
	}
	public ArrayList<CustomerDto> getAllMobiles()
			throws MobilePurchaseSystemException{
		return mpDao.getAllMobiles();
	}
	public ArrayList<CustomerDto> getSearchedMobiles(int min, int max) {
		return mpDao.getSearchedMobiles(min, max);
	}
	public boolean isThere(long mobileId) {
		return mpDao.isThere(mobileId);
	}
	public void delRecord(int del) throws MobilePurchaseSystemException {
		mpDao.delRecordsSql(del);
		}
	
	@Override
	public boolean ValidateCustomerName(String custerName) {
		String namePattern = "[A-Z][a-z]{1,19}";
		if(Pattern.matches(namePattern,custerName))
			return true;
		return false;
	}

	@Override
	public boolean ValidateMailId(String mailId) {
		String mailIdPattern = "[A-Za-z0-9]{1,20}[@][A-Za-z]{3,15}[.][A-Za-z]{1,15}";
		if(Pattern.matches(mailIdPattern,mailId))
			return true;
		return false;
	}

	@Override
	public boolean ValidatePhoneNumber(String phoneNum) {
		String mobilePattern = "[0-9]{10}";
		if(Pattern.matches(mobilePattern,phoneNum))
			return true;
		return false;
	}

	@Override
	public boolean ValidateMobileId(long mobileId) {
		String str=Long.toString(mobileId);
		String mobileIdPattern = "[0-9]{4}";
		if(Pattern.matches(mobileIdPattern,str))
			return true;
		return false;
	}

	@Override
	public boolean ValidatePurchaseId(String purchaseId) {
		String purchaseIdPattern = "[0-9]{4}";
		if(Pattern.matches(purchaseIdPattern,purchaseId))
			return true;
		return false;
	}

	






	




	
	

}
