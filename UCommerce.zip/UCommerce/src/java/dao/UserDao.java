/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.ProductModel;
import model.UserModel;

/**
 *
 * @author Ganesh
 */
public class UserDao {

    public static UserModel authenticateUser(String email, String password) {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from users where user_email = ? and password = ?");
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            UserModel model = null;
            if (rs.next()) {
                model = new UserModel();
                model.setId(rs.getInt(1));
                model.setUserName(rs.getString(2));
                model.setUserEmail(rs.getString(3));
                model.setPassword(rs.getString(4));
                model.setAge(rs.getInt(5));
                model.setOccupation(rs.getString(6));
                model.setGender(rs.getString(7));
            }
            rs.close();
            return model;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }

    }

    public static String getUserPreferences(int userId) {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from user_preferences where user_id = ?");
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            String details = null;
            details = rs.next() ? rs.getString(3) : null;
            rs.close();
            return details;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }
    }
    
    public static String getProductType(String productName) {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select type from products where product_name = ?");
            ps.setString(1, productName);
            ResultSet rs = ps.executeQuery();
            String type = null;
            if(rs.next()) {
                type = rs.getString(1);
            }
            rs.close();
            return type;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }
    }

    public static List<Integer> process(int id) {
        try {
            String details = getUserPreferences(id);
            List<Integer> list = new ArrayList<>();
            if (details != null) {
                String patterns[] = details.split(",");
                for (String s : patterns) {
                    int productId = getProductId(s);
                    list.add(productId);
                    String type = getProductType(s);
                    List<Integer> idsList = getProductList(type);
                    for(Integer integerList : idsList) {
                        if(!list.contains(integerList)) {
                            list.add(integerList);
                        }
                    }
                }
            }

            return list;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        }
    }

    private static int getProductId(String name) {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select id from products where product_name = ?");
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            int value = rs.next() ? rs.getInt(1) : -1;
            rs.close();
            return value;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return -1;
        } finally {
            Database.close(con);
        }
    }

    private static List<Integer> getProductList(String type) {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT product_id FROM `transactions` WHERE product_id in (select id from products where type = '"+type+"' and date_of_purchase >= NOW() - INTERVAL 8 MONTH)");
            ResultSet rs = ps.executeQuery();
            List<Integer> list = new ArrayList<>();
            while (rs.next()) {
                list.add(rs.getInt(1));
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }
    }

    public static List<ProductModel> getProducts(int id) {
        Connection con = null;
        try {
            List<Integer> productIds = process(id);
            if (productIds != null && productIds.size() > 0) {
                String details = "";
                for (Integer i : productIds) {
                    details += (i + ",");
                }
                details = details.substring(0, details.length() - 1);
                con = Database.getConnection();
                PreparedStatement ps = con.prepareStatement("select * from products where id in (" + details + ")");
                ResultSet rs = ps.executeQuery();
                List<ProductModel> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(new ProductModel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6)));
                }
                rs.close();
                return list;

            } else {
                return null;
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }
    }

    

}
