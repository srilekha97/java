/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.TransactionModel;

/**
 *
 * @author Ganesh
 */
public class TransactionDao {
    
    
    public static List<TransactionModel> getList() {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from transactions");
            ResultSet rs = ps.executeQuery();
            List<TransactionModel> li = new ArrayList<>();
            while(rs.next()) {
                TransactionModel model = new TransactionModel();
                model.setId(rs.getInt(1));
                model.setProductId(rs.getInt(2));
                model.setUserId(rs.getInt(3));
                model.setPriceSlab(rs.getInt(4));
                model.setDateOfPurchase(rs.getString(5));
                li.add(model);
            }
            rs.close();
            return li;
            
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);;
        }
    }
    
    
}
