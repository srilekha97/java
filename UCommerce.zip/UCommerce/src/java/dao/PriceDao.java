/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.SlabModel;

/**
 *
 * @author Ganesh
 */
public class PriceDao {
    
    public static List<SlabModel> getList() {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from price_slabs");
            ResultSet rs = ps.executeQuery();
            List<SlabModel> li = new ArrayList<>();
            while(rs.next()) {
                SlabModel model = new SlabModel();
                model.setId(rs.getInt(1));
                model.setPrice(rs.getInt(3));
                model.setSlab(rs.getString(2));
                li.add(model);
            }
            rs.close();
            return li;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }
        
    } 
    
    
    
    
}
