/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.ProductModel;

/**
 *
 * @author Ganesh
 */
public class ProductDao {

    public static List<ProductModel> getProductList() {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from products");
            ResultSet rs = ps.executeQuery();
            List<ProductModel> list = new ArrayList<>();
            while (rs.next()) {
                list.add(new ProductModel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6)));
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }
    }

    public static List<String> getProductTypes() {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select distinct type from products");
            ResultSet rs = ps.executeQuery();
            List<String> list = new ArrayList<>();
            while (rs.next()) {
                list.add(rs.getString(1));
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }
    }

    public static List<ProductModel> getProductsList(String type) {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from products where type = ?");
            ps.setString(1, type);
            ResultSet rs = ps.executeQuery();
            List<ProductModel> list = new ArrayList<>();
            while (rs.next()) {
                list.add(new ProductModel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6)));
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }
    }

    public static List<ProductModel> getProductSearchList(String type) {
        Connection con = null;
        try {
            con = Database.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from products where product_name like '%" + type.toLowerCase() + "%'");
            ResultSet rs = ps.executeQuery();
            List<ProductModel> list = new ArrayList<>();
            while (rs.next()) {
                list.add(new ProductModel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6)));
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        } finally {
            Database.close(con);
        }
    }

}
