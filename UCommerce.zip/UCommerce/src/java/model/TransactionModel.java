/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Ganesh
 */
public class TransactionModel {
    
    
    private int id;
    private int productId;
    private int userId;
    private int priceSlab;
    private String dateOfPurchase;

    public TransactionModel() {
    }

    public TransactionModel(int id, int productId, int userId, int priceSlab, String dateOfPurchase) {
        this.id = id;
        this.productId = productId;
        this.userId = userId;
        this.priceSlab = priceSlab;
        this.dateOfPurchase = dateOfPurchase;
    }

    @Override
    public String toString() {
        return "TransactionModel{" + "id=" + id + ", productId=" + productId + ", userId=" + userId + ", priceSlab=" + priceSlab + ", dateOfPurchase=" + dateOfPurchase + '}';
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getPriceSlab() {
        return priceSlab;
    }

    public void setPriceSlab(int priceSlab) {
        this.priceSlab = priceSlab;
    }

    public String getDateOfPurchase() {
        return dateOfPurchase;
    }

    public void setDateOfPurchase(String dateOfPurchase) {
        this.dateOfPurchase = dateOfPurchase;
    }
    
    
    
    
    
}
