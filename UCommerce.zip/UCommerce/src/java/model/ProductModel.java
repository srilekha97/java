/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Ganesh
 */
public class ProductModel {
    private int id;
    private String productName;
    private String type;
    private String genderSpecific;
    private String imageUrl;
    private int price;

    public ProductModel() {
    }

    public ProductModel(int id, String productName, String type, String genderSpecific, String imageUrl, int price) {
        this.id = id;
        this.productName = productName;
        this.type = type;
        this.genderSpecific = genderSpecific;
        this.imageUrl = imageUrl;
        this.price = price;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ProductModel other = (ProductModel) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    
    
    
    
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getGenderSpecific() {
        return genderSpecific;
    }

    public void setGenderSpecific(String genderSpecific) {
        this.genderSpecific = genderSpecific;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    
    
    
}
