/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo;

import dao.TransactionDao;
import java.util.ArrayList;
import java.util.List;
import model.TransactionModel;

/**
 *
 * @author Ganesh
 */
public class Clusters {

    public List<List<TransactionModel>> getInitialClusers() {
        int initialMidpoints[] = {10, 20, 30};
        List<List<TransactionModel>> clusters = getInitialBucketReady(initialMidpoints.length);
        List<TransactionModel> rawData = TransactionDao.getList();
        if (rawData != null) {
            for(TransactionModel model : rawData) {
                int position = getNearestCluster(initialMidpoints, model);
                clusters.get(position).add(model);
            }
        }
        return clusters;
    }

    private List<List<TransactionModel>> getInitialBucketReady(int length) {
        List<List<TransactionModel>> list = new ArrayList<>();
        for (int i = 0; i < length; i++) {
            List<TransactionModel> model = new ArrayList<>();
            list.add(model);
        }
        return list;
    }
    
    private int getNearestCluster(int[] midpoints, TransactionModel point) {
        int minDistances[] = new int[midpoints.length];
        for(int i = 0; i < midpoints.length; i++) {
            minDistances[i] = Math.abs(point.getPriceSlab() - midpoints[i]);
        }
        int minCalculation = Integer.MAX_VALUE;
        int position = 0;
        for(int i = 0; i < minDistances.length; i++) {
            if(minCalculation > minDistances[i]) {
                position = i;
                minCalculation = minDistances[i];
            }
        }
        
        return position;
    }
    
    
}
