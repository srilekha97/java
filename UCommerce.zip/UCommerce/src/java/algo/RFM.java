/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo;

import dao.ProductDao;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.ProductModel;
import model.TransactionModel;

/**
 *
 * @author Ganesh
 */
public class RFM {

    private final List<ProductModel> list = ProductDao.getProductList();
    
    

    public List<FrequencyPattern> getFrequentList(List<TransactionModel> list) {
        List<ProductModel> products = getDistinctProducts(list);
        List<FrequencyPattern> frequency = new ArrayList<>();
        for (ProductModel product : products) {
            int productCount = 0;
            for (TransactionModel model : list) {
                if (product.getId() == model.getProductId()) {
                    productCount += 1;
                }
            }

            frequency.add(new FrequencyPattern(product, productCount));
        }
        return frequency;

    }

    public List<ProductModel> getRecentList(List<TransactionModel> list) {
        int threshold = 15;
        List<ProductModel> li = new ArrayList<>();
        for (TransactionModel model : list) {
            int dateDifference = this.differenceBetweenDays(model.getDateOfPurchase());
            if (dateDifference <= threshold) {
                li.add(getProductModel(model.getProductId()));
            }
        }

        return li;
    }

    private List<ProductModel> getDistinctProducts(List<TransactionModel> list) {
        List<ProductModel> products = new ArrayList<>();
        for (TransactionModel model : list) {
            ProductModel product = getProductModel(model.getId());
            if (!products.contains(product)) {
                products.add(product);
            }
        }
        return products;
    }

    private ProductModel getProductModel(int productId) {

        for (ProductModel model : list) {
            if (model.getId() == productId) {
                return model;
            }
        }
        return null;
    }

    

    private int differenceBetweenDays(String toDate) {
        try {
            Date dateAfter = new Date();
            Date dateBefore = new SimpleDateFormat("yyyy-MM-dd").parse(toDate);
            long difference = dateAfter.getTime() - dateBefore.getTime();
            float daysBetween = (difference / (1000 * 60 * 60 * 24));
            return (int) daysBetween;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return 0;
        }
    }

}
