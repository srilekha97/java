/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo;

import dao.UserDao;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import model.ProductModel;
import model.TransactionModel;

/**
 *
 * @author Ganesh
 */
public class UserBehaviour {
    private RFM rfm;
    public UserBehaviour() {
        rfm = new RFM();
    }
    
    public List<ProductModel> process(int userId) {
        try {
            List<List<TransactionModel>> list = new Clusters().getInitialClusers();
            String details = UserDao.getUserPreferences(userId);
            String[] values = details.split(",");
            List<ProductModel> productsList = new ArrayList<>();
            for(List<TransactionModel> transactions : list) {
               List<ProductModel> recent = rfm.getRecentList(transactions);
               List<FrequencyPattern> frequency = rfm.getFrequentList(transactions);
               Collections.sort(frequency);
               for(ProductModel pr : recent) {
                  for(String s : values) {
                      if(s.trim().equals(pr.getProductName())) {
                          productsList.add(pr);
                      }
                  }
               }
               for(FrequencyPattern pattern : frequency) {
                   productsList.add(pattern.getPoint());
               }
               
            }
            
            return productsList;
            
        } catch(Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        }
    }
    
    
    
    
    
    
}
