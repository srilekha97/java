/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo;

import model.ProductModel;

/**
 *
 * @author Ganesh
 */
public class FrequencyPattern implements Comparable<FrequencyPattern> {

    public FrequencyPattern(ProductModel point, int frequency) {
        this.point = point;
        this.frequency = frequency;
    }

    public FrequencyPattern() {
    }
    
    
    
    private ProductModel point;
    private int frequency;

    public ProductModel getPoint() {
        return point;
    }

    public void setPoint(ProductModel point) {
        this.point = point;
    }

    public int getFrequency() {
        return frequency;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    @Override
    public int compareTo(FrequencyPattern o) {
        return (o.frequency - this.frequency);
    }
    
    
    
}
