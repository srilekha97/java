package com.capgemini.doctors.service;

import java.util.ArrayList;
import java.util.regex.Pattern;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDAO;
import com.capgemini.doctors.exceptions.DoctorAppointmentException;

public class DoctorAppointmentService implements IDoctorAppointmentService
{
	DoctorAppointmentDAO Dao;
	public DoctorAppointmentService(){
		Dao = new DoctorAppointmentDAO();
	}
	
	public long getAppointmentID() throws DoctorAppointmentException {

		return Dao.getAppointmentID();
	}
	
	public int AddDoctorAppointmentDetails(DoctorAppointment doctorappointment) throws DoctorAppointmentException
	{
		return Dao.AddDoctorAppointmentDetails(doctorappointment);
	}
	
	public DoctorAppointment GetAppointmentDetails(int id) throws DoctorAppointmentException 
	{
		return Dao.GetAppointmentDetails(id);
	}
	

	
	public boolean validateName(String str)
	{
    String namePattern = "[A-Z][A-Za-z ]{1,20}";
	if(Pattern.matches(namePattern,str))
		return true;
	else
		return false;
	}
	
	
	public boolean validateEmail(String str)
	{
		if(Pattern.matches("[A-Za-z0-9]{1,20}[@][A-Za-z]{1,15}[.][A-Za-z]{1,15}",str))
			return true;
		else
			return false;
	}
	
	public boolean validatePhoneNumber(String str)
	{
		if(Pattern.matches("\\d{10}",str))
			return true;
		else
			return false;
	}
	
	public boolean validateAge(String age)
	{
	if(Pattern.matches("\\d{2}",age))
		return true;
	else
		return false;
	}
	
	public boolean validateGender(String gender) 
	{
	if((gender.equals("Male"))||(gender.equals("Female")))
		return true;
	else
		return false;
	}

	public String getDoctorName(String problem) {
		// TODO Auto-generated method stub
		String str;
		if(problem.contentEquals("Heart"))
			return "Dr.Brijesh Kumar";
		else if(problem.contentEquals("Gynecology"))
			return "Dr. Shardha singh";
		else if(problem.contentEquals("ENT"))
			return "Dr. Heena quereshi";
		else if(problem.contentEquals("Bone"))
			return "Dr. Mandeep Kumar";
		else
		return null;
	}
	
	
	
	
}
