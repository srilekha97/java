package com.capgemini.doctors.service;

import java.util.ArrayList;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exceptions.DoctorAppointmentException;

public interface IDoctorAppointmentService 
{
	public long getAppointmentID() throws DoctorAppointmentException;
	public int AddDoctorAppointmentDetails(DoctorAppointment doctorappointment) throws DoctorAppointmentException;
	public DoctorAppointment GetAppointmentDetails(int id) throws DoctorAppointmentException;
}
