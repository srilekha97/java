package com.capgemini.doctors.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDAO;
import com.capgemini.doctors.exceptions.DoctorAppointmentException;
import com.capgemini.doctors.service.DoctorAppointmentService;

public class UI {
	private static Scanner in;
	static DoctorAppointmentService service= new DoctorAppointmentService();

	public static void main(String[] args) throws DoctorAppointmentException {
		in = new Scanner(System.in);
		System.out.println("Welocome To Mobile Regsitration Portal");
		String choice = "null";
		
		while (!choice.equals("3")) {
			System.out.println("Enter your choice");
			System.out.println("1) Insert Patient Details ");
			System.out.println("2) Display stAtus of appointment");
			System.out.println("3) EXIT ");
			choice = in.next().trim();
			switch (choice) 
			{
			case "1": 
					addDetails();
					break;
			case "2":
				getDetails();
				break;
		
			case "3":
				System.out.println("Thank you.... Program terminated");
				System.exit(0);
				break;
				
			default:
				System.out.println("WRONG CHOICE chosen...Please enter a valid choice");
			}
		}
		System.out.println("Thank you.... program terminated");
	}

	
	private static void addDetails() throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		DoctorAppointment dtoOBJ = new DoctorAppointment();
		DoctorAppointmentDAO daoOBJ = new DoctorAppointmentDAO();
		DoctorAppointmentService serv= new DoctorAppointmentService();
		
		String Name="?";
		String mailId="?";
		String phoneNumber="?";
		String problem="";
		String age="";
		String gender="";
		String doctor="";
		String Appointmentstatus="";
		
		Date today=new Date();
		long ltime=today.getTime()+24*60*60*1000;
		Date appmentDate=new Date(ltime);
		boolean status=true;
		int count=3;
		
		while(status)
		{
			System.out.println("Enter Patient Name");
			Name=in.next();
			if(serv.validateName(Name)==true)
			{
				status=true; break;
			}
			else
			{
			System.out.println("Name should start with captital letters.. enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		count=3;
		while(status)
		{
			System.out.println("Enter Patient Mail id");
			mailId=in.next();
			if(serv.validateEmail(mailId)==true){
				status=true; break;
			}
			else
			{
			System.out.println("Wrong mail id given.. enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		count=3;
		while(status)
		{
			System.out.println("Enter Patient Mobile number");
			phoneNumber=in.next();
			if(serv.validatePhoneNumber(phoneNumber)==true){
				status=true; break;
			}
			else
			{
			System.out.println("Wrong mobile number given.. enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		count=3;
		while(status)
		{
			System.out.println("Enter Patient age");
			age=in.next();
			if(serv.validateAge(age)==true)
			{
				status=true; break;
			}
			else
			{
			System.out.println("Wrong age given.. enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		
		count=3;
		while(status)
		{
			System.out.println("Enter Patient gender");
			gender=in.next();
			if(serv.validateGender(gender)==true){
				status=true; break;
			}
			else
			{
			System.out.println("Gender should be either Male or Female only... enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		if(status)
		{
			System.out.println("Enter Patient Problem");
			problem=in.next();
			doctor=serv.getDoctorName(problem);
			if(doctor!=null)
			{
				dtoOBJ.setAppointmentStatus("Approved");
				dtoOBJ.setProblemName(problem);
				dtoOBJ.setDoctorName(doctor);
			}
				
			else
			{
				dtoOBJ.setProblemName("Others");
			}
			
			}
		
		
		if(status==true)
		{
			dtoOBJ.setPatientName(Name);
			dtoOBJ.setPatientEmail(mailId);
			dtoOBJ.setPatientPhNum(phoneNumber);
			dtoOBJ.setAppointmentDate(appmentDate);
			dtoOBJ.setPatientAge(age);
			dtoOBJ.setPatientGender(gender);
			serv.AddDoctorAppointmentDetails(dtoOBJ);
				
			System.out.println("****All details updated successfully*****");
			System.out.println("Patient name:" + dtoOBJ.getPatientName());
			System.out.println("Patient phone  number:" + dtoOBJ.getPatientPhNum());
			System.out.println("Patient email id:" + dtoOBJ.getPatientEmail());
			System.out.println("Patient age:" + dtoOBJ.getPatientAge());
			System.out.println("Patient gender:" + dtoOBJ.getPatientGender());
			System.out.println("Patient problem:" + dtoOBJ.getProblemName());
			System.out.println("appointment :" + dtoOBJ.getAppointmentStatus());
			
			System.out.println("Your appointment ID is:" + serv.getAppointmentID() + "\n");
		}
				else
			System.out.println("All details wrongly entered...\n");
	}
		
	

	private static void getDetails() throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		DoctorAppointment dtoOBJ = new DoctorAppointment();
		DoctorAppointmentDAO daoOBJ = new DoctorAppointmentDAO();
		DoctorAppointmentService serv= new DoctorAppointmentService();
		
		System.out.println("enter appointment id");
		int id=in.nextInt(); 
		dtoOBJ=serv.GetAppointmentDetails(id);
		if(dtoOBJ!=null)
		{
			System.out.println("PATIENT NAME=" + dtoOBJ.getPatientName());
			System.out.println("APPOINTMENT STATUS=" + dtoOBJ.getAppointmentStatus());
			System.out.println("DOCTOR NAME=" + dtoOBJ.getDoctorName());
			System.out.println("DATE =" + dtoOBJ.getAppointmentDate() + "\n");
		}
	
	}

	
	
}
