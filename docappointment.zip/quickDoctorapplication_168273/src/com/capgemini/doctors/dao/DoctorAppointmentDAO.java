package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.capgemini.MPS.util.DBConnection;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exceptions.DoctorAppointmentException;


public class DoctorAppointmentDAO implements IDoctorAppointmentDAO 
{
	private Logger logger = Logger.getLogger(DoctorAppointmentDAO.class);	
	public DoctorAppointmentDAO()
	{
	PropertyConfigurator.configure("log4j.properties");
	}

	
	public int AddDoctorAppointmentDetails(DoctorAppointment doctorappointment) throws DoctorAppointmentException
	{
		logger.info("Customer registration started");
		Connection conn;
		PreparedStatement insertStmt = null;
		
		try
		{
	
			int age = Integer.parseInt(doctorappointment.getPatientAge());
			
			Date today=new Date();
			long ltime=today.getTime()+24*60*60*1000;
			Date appmentDate=new Date(ltime);
			java.sql.Date sqlDate = new java.sql.Date(appmentDate.getTime());
			
			conn=DBConnection.getConnection();
			insertStmt=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1,doctorappointment.getPatientName());
			insertStmt.setString(2,doctorappointment.getPatientPhNum());
			insertStmt.setDate(3,sqlDate);
			insertStmt.setString(4,doctorappointment.getPatientEmail());
			insertStmt.setInt(5,age);
			insertStmt.setString(6,doctorappointment.getPatientGender());
			insertStmt.setString(7,doctorappointment.getProblemName());
			insertStmt.setString(8,doctorappointment.getDoctorName());
			insertStmt.setString(9,doctorappointment.getAppointmentStatus());
			
			int result = insertStmt.executeUpdate();
			
			if(result!=1)
			{
				logger.debug("value not inserted");
				throw new DoctorAppointmentException("sorry, cant process the request");
			}
			else
			{
				conn.commit();
			}
		}
		catch(DoctorAppointmentException e)
		{
			throw new DoctorAppointmentException("sorry not updated.... doctorappointment exception");
		}
		catch(SQLException e)
		{
			throw new DoctorAppointmentException("sorry not updated... sql exception");
		}
		return 0;
	}
	
	



	
	public DoctorAppointment GetAppointmentDetails(int id) throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		logger.info("Customer registration started");
		Connection conn;
		PreparedStatement getStmt = null;
		DoctorAppointment bin = new DoctorAppointment();
		
		try
		{
			conn=DBConnection.getConnection();
			getStmt=conn.prepareStatement(IQueryMapper.GET_STATUS);
			getStmt.setInt(1,id);
			java.sql.Date sqlDate = new java.sql.Date(0);
			
			
			ResultSet set = getStmt.executeQuery();
			if(set.next()) {
			bin.setPatientName(set.getString(1));
			bin.setAppointmentStatus(set.getString(2));
			bin.setDoctorName(set.getString(3));
			bin.setAppointmentDate(sqlDate);
			}
			else
			{
				System.out.println("There are no details with the given appointment id");
				bin=null;
			}
				conn.commit();
		}
		catch(DoctorAppointmentException e)
		{
			throw new DoctorAppointmentException("sorry not updated.... doctorappointment exception");
		}
		catch(SQLException e)
		{
			throw new DoctorAppointmentException("sorry not updated... sql exception");
		}
		
		return bin;
	}


	
	
	public long getAppointmentID() throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		Connection conn;
		long val=0;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement=null;		
		
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_AID);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				val=resultSet.getLong(1);
			}
		}
		catch(SQLException e)
		{
			throw new DoctorAppointmentException("sorry not updated");
		}
		catch(DoctorAppointmentException e)
		{
			throw new DoctorAppointmentException("sorry not updated");
		}
		
		return val;
	}
}

